install.packages("OpenML", dependencies = TRUE)
library(OpenML)
setOMLConfig(apikey = "623ef455a837cc8685bbdbf2d144e23c")

num_errors = 0

for (num_cl in 2:8) {
  task_list <- listOMLTasks(task.type = "Supervised Classification", number.of.classes = num_cl, number.of.instances = c(2000,1000000))
  task_id_list <- task_list$task.id
  for (i in 1:length(task_id_list)) {
    tryCatch({
      task_id <- task_id_list[i]
      task <- getOMLTask(task.id = task_id)
      data <- task$input$data.set$data
      data$row_id <- seq.int(nrow(data)) - 1
      
      runs <- listOMLRunEvaluations(task.id = task_id, limit = 5)
      if (nrow(runs) == 0) next
      
      for (j in 1:nrow(runs)) {
        run_id = runs[j,"run.id"]
        
        run <- getOMLRun(run.id = run_id)
        predictions <- run$predictions
        
        verify_predic <- TRUE
        
        for (cl in 1:length(levels(predictions$correct))) {
          if (0 %in% predictions[[paste("confidence.",levels(predictions$correct)[cl], sep="")]]) {
            verify_predic <- FALSE
          }
        }
        
        if (!verify_predic) {
          next
        }
        if (nrow(predictions) != nrow(data)) {
          predictions <- predictions[predictions$'repeat' == 0, ]
        }
        predictions <- predictions[order(predictions$row_id),]
        predictions <- merge(data, predictions, by = "row_id")
        number_of_folds <- length(unique(predictions$fold))
        if (number_of_folds == 1) {
          next
        }
        predictions <- split( predictions , f = predictions$fold )
        for (z in 1:min(10, number_of_folds)) {
          write.csv(predictions[z], paste("../predictions/", paste(task_id, run_id, z,sep="_"), sep=""))
        }

      }
      
      
    }, error = function(err) {
      print(err)
      num_errors = num_errors + 1
    })
  }
}
print(paste("Number of errors during run: ", num_errors))
