library(dplyr)
library(ggplot2)
library(gridExtra)
library(tidyr)

source("split_violins.R")

data <- read.csv("final_results.csv")
#data <- data[data$under_sampled_class_amount == 0,]
#data <- data[data$under_sampled_covariate_amount == 0,]
#data <- data[data$flip_class_amount == 0,]

mse <- function(x) {
  a <- as.character(x["preshift_pi"])
  a <- strsplit(a, split = " ")[[1]]
  a <- a[a != "" & a != "[" & a != "]"]
  for (i in 1:length(a)) {
    a[i] <- gsub("]", "", gsub("[", "", a[i], fixed = TRUE), fixed = TRUE)
  }
  b <- as.character(x["postshift_pi"])
  b <- strsplit(b, split = " ")[[1]]
  b <- b[b != "" & b != "[" & b != "]"]
  for (i in 1:length(b)) {
    b[i] <- gsub("]", "", gsub("[", "", b[i], fixed = TRUE), fixed = TRUE)
  }
  
  a <- as.numeric(a)
  b <- as.numeric(b)
  
  return(mean((a - b)**2))
}

data$shift_mse <- apply(data[,c("preshift_pi", "postshift_pi")], 1, mse)

breaks <- quantile(data$shift_mse, prob = c(0, 1/3, 2/3, 1.0))
data$shift_mse_group <- as.numeric(cut(data$shift_mse, breaks = breaks))

#####################################################
data$normalized_loss1 <- (data$postshift_unadj_LL - data$postshift_add_adj_LL) / data$postshift_unadj_LL
data$normalized_loss2 <- (data$postshift_unadj_LL - data$postshift_mul_adj_LL) / data$postshift_unadj_LL
#####################################################


data_long <- gather(data, key = adjustment_type, value = improvement, normalized_loss1, normalized_loss2)
data_long$fill_var <- 1

data_long$shift_mse_group <- factor(data$shift_mse_group)

myplot <- function(err, shift) {
  g <- ggplot(filter(data_long,
                     error_amount == err | error_amount == -1*err,
                     shift_mse_group == shift), aes(x = fill_var, y = improvement, fill = adjustment_type)) + 
    geom_hline(yintercept = 0, col = "red") +
    #geom_violin() +
    geom_split_violin(draw_quantiles = c(0.5)) + 
    theme(axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          axis.ticks.x = element_blank(),
          axis.ticks.y = element_blank(),
          legend.position = "none")+
    scale_y_continuous(limits=c(-0.1, 1))
  return(g)
}

myplot_with_ticks <- function(err, shift) {
  g <- ggplot(filter(data_long,
                     error_amount == err | error_amount == -1*err,
                     shift_mse_group == shift), aes(x = fill_var, y = improvement, fill = adjustment_type)) + 
    geom_hline(yintercept = 0, col = "red") +
    #geom_violin() +
    geom_split_violin(draw_quantiles = c(0.5)) + 
    theme(axis.text.x = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          axis.ticks.x = element_blank(),
          legend.position = "none")+
    scale_y_continuous(limits=c(-0.1, 1))
  return(g)
}

a11 <- myplot_with_ticks(0, "3")
a12 <- myplot(0.01, 3)
a13 <- myplot(0.02, 3)
a14 <- myplot(0.04, 3)
a15 <- myplot(0.08, 3)
a21 <- myplot(0, 2)
a22 <- myplot(0.01, 2)
a23 <- myplot(0.02, 2)
a24 <- myplot(0.04, 2)
a25 <- myplot(0.08, 2)
a31 <- myplot(0, 1)
a32 <- myplot(0.01, 1)
a33 <- myplot(0.02, 1)
a34 <- myplot(0.04, 1)
a35 <- myplot(0.08, 1)

gridExtra::grid.arrange(a11, a12, a13, a14, a15,
                        a21, a22, a23, a24, a25,
                        a31, a32, a33, a34, a35,
                        ncol = 5, nrow = 3)

