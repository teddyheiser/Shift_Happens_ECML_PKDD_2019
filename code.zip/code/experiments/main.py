from adjusters import *
from loss_functions import *
from data_parsing import *
from shifting import *
import os
import random
import time
import traceback
import numpy as np
import pandas as pd

path = "../predictions/"
file_names = [path + f_name for f_name in os.listdir(path)]

random.seed(1)

data_frame = pd.DataFrame(columns=['name',
                    'preshift_num_of_instances','postshift_num_of_instances',
                    'preshift_BS','postshift_unadj_BS',
                    'postshift_add_adj_BS','postshift_mul_adj_BS','postshift_pps_adj_BS',
                    'preshift_LL','postshift_unadj_LL',
                    'postshift_add_adj_LL','postshift_mul_adj_LL','postshift_pps_adj_LL',
                    'preshift_pi','postshift_pi','error_amount','estimated_pi',
                    'preshift_expected_prediction','postshift_unadj_expected_prediction',
                    'postshift_PPS_adj_expected_prediction',
                    'postshift_add_adj_expected_prediction',
                    'postshift_mul_adj_expected_prediction',
                    'under_sampled_class_amount','under_sampled_covariate_amount','flip_class_amount',
                    'add_adj_solver', 'mul_adj_solver'])

dataset_counter = 0

shift_indicators = [[True, False, False],
                    [False, True, False],
                    [False, False, True],
                    [True, True, True]]

shift_min = 0.1
shift_max = 0.5

errors = [0, 0.01, 0.02, 0.04, 0.08, -0.01, -0.02, -0.04, -0.08]

format_error_counter = 0
shift_error_counter = 0
opt_error_counter = 0

for f_name in file_names:

    data = pd.read_csv(f_name)
    if data.values.shape[0] > 1000:
        data = data.sample(1000)
    if data.values.shape[0] < 500:
        continue # too few instances

    for shift_indicator in shift_indicators:

        header = data.columns.values.tolist()[1][0:3]
        if header + "correct" not in data.columns.values.tolist():
            format_error_counter += 1
            continue # file in the wrong format

        class_names = get_class_names(data)

        p = get_confidences(data, class_names, len(class_names))
        y = get_labels(data, class_names)
        features = get_covariates(data, class_names)

        initial_avg_loss_BS = average_loss(brier_scorer, p, y)
        initial_avg_loss_LL = average_loss(log_losser, p, y)
        initial_expect_pred = get_pi(p)

        big_classes = get_big_classes(y)
        small_classes = get_small_classes(y.shape[1], big_classes)

        pre_n = p.shape[0]

        old_pi = get_pi(y)

        under_sampled_class_amount = 0.0
        under_sampled_covariate_amount = 0.0
        flip_class_amount = 0.0

        try:
            if shift_indicator[1]:
                under_sampled_covariate_amount = random.uniform(shift_min, shift_max)
                p, y = cov_shifter(p, y, under_sampled_covariate_amount, features, big_classes, small_classes)
                if (pre_n == p.shape[0]):
                    continue # no shifting occurred
            if shift_indicator[0]:
                under_sampled_class_amount = random.uniform(shift_min, shift_max)
                p, y = prior_shifter(p, y, under_sampled_class_amount, big_classes, small_classes)
            if shift_indicator[2]:
                flip_class_amount = random.uniform(shift_min, shift_max)
                p, y = flip_prior_shifter(p, y, flip_class_amount, big_classes, small_classes)
        except Exception as e:
            shift_error_counter += 1
            with open("errors.txt", "a") as myfile:
                    myfile.write(f_name + "\n" + "Shifting Error" + "\n" + str(e) + "\n")
            with open("errors.txt", "a") as myfile:
                    myfile.write(traceback.format_exc() + "\n\n")
            continue # shifting error occurred, experiment ruined

        unadj_avg_loss_BS = average_loss(brier_scorer, p, y)
        unadj_avg_loss_LL = average_loss(log_losser, p, y)
        unadj_expect_pred = get_pi(p)

        for error in errors:

            new_pi = get_pi(y)

            error_pi = np.copy(new_pi)
            for i in big_classes:
                error_pi[i] += error
            for i in small_classes:
                error_pi[i] -= error*len(big_classes)/len(small_classes)

            pi_broke = False
            for i in error_pi.tolist():
                if i < 0.005:
                    pi_broke = True
                if i > 0.995:
                    pi_broke = True
            if pi_broke:
                continue # estimated class distribution is outside [0,1], which is nonsense

            pi_unchanged = True
            for i in range(len(error_pi.tolist())):
                if abs(error_pi.tolist()[i] - old_pi.tolist()[i]) > 0.01:
                    pi_unchanged = False
            if pi_unchanged:
                continue # estimated class distribution didn't change enough

            adjusted_PPS_p = PPS_adjuster(p, error_pi, error, big_classes, small_classes)
            avg_loss_PPS_BS = average_loss(brier_scorer, adjusted_PPS_p, y)
            avg_loss_PPS_LL = average_loss(log_losser, adjusted_PPS_p, y)
            new_PPS_E = get_pi(adjusted_PPS_p)

            try:
                adjusted_add_gen_p, BS_solver = BS_general_adjuster(p, error_pi, error, big_classes, small_classes)
                avg_loss_add_gen_BS= average_loss(brier_scorer, adjusted_add_gen_p, y)
                avg_loss_add_gen_LL = average_loss(log_losser, adjusted_add_gen_p, y)
                new_add_gen_E = get_pi(adjusted_add_gen_p)

            except Exception as e:
                avg_loss_add_gen_BS = 0.0
                avg_loss_add_gen_LL = 0.0
                new_add_gen_E = error_pi
                with open("errors.txt", "a") as myfile:
                        myfile.write(f_name + "\n" + "Solver Error" + "\n" + str(e) + "\n")
                with open("errors.txt", "a") as myfile:
                        myfile.write(traceback.format_exc() + "\n\n")
                opt_error_counter += 1

            try:
                adjusted_mul_gen_p, LL_solver = LL_general_adjuster(p, error_pi, error, big_classes, small_classes)
                avg_loss_mul_gen_BS= average_loss(brier_scorer, adjusted_mul_gen_p, y)
                avg_loss_mul_gen_LL = average_loss(log_losser, adjusted_mul_gen_p, y)
                new_mul_gen_E = get_pi(adjusted_mul_gen_p)

            except Exception as e:
                avg_loss_mul_gen_BS = 0.0
                avg_loss_mul_gen_LL = 0.0
                new_mul_gen_E = error_pi
                with open("errors.txt", "a") as myfile:
                        myfile.write(f_name + "\n" + "Solver Error" + "\n" + str(e) + "\n")
                with open("errors.txt", "a") as myfile:
                        myfile.write(traceback.format_exc() + "\n\n")
                opt_error_counter += 1

            data_frame.loc[dataset_counter] = [f_name,
                                pre_n, p.shape[0],
                                initial_avg_loss_BS, unadj_avg_loss_BS,
                                avg_loss_add_gen_BS, avg_loss_mul_gen_BS, avg_loss_PPS_BS,
                                initial_avg_loss_LL, unadj_avg_loss_LL,
                                avg_loss_add_gen_LL, avg_loss_mul_gen_LL, avg_loss_PPS_LL,
                                old_pi, new_pi, error, error_pi,
                                initial_expect_pred, unadj_expect_pred,
                                new_PPS_E,
                                new_add_gen_E,
                                new_mul_gen_E,
                                under_sampled_class_amount, under_sampled_covariate_amount, flip_class_amount,
                                BS_solver, LL_solver]
            dataset_counter +=1


print("Files in wrong format: " + str(format_error_counter))
print("Overall number of shifting errors: " + str(shift_error_counter))
print("Overall number of optimizer errors: " + str(opt_error_counter))
data_frame.to_csv("final_results.csv", sep=',')
