import numpy as np
import math
import random

def get_number_of_class(p_and_y, cl):
    class_num = 0
    for i in range(p_and_y.shape[0]):
        if (p_and_y[i,(p_and_y.shape[1]//2)+cl] == 1):
            class_num += 1
    return class_num


def prior_shifter(p_, y_, shift_amount, big_classes, small_classes):
    p = p_
    y = y_
    p_and_y = np.concatenate((p, y), axis = 1)
    np.random.shuffle(p_and_y)

    for cl in big_classes:
        p_and_y = p_and_y[p_and_y[:,(p_and_y.shape[1]//2)+cl].argsort()]
        number_of_majority_class = get_number_of_class(p_and_y, cl)
        p_and_y = p_and_y[math.floor(number_of_majority_class*shift_amount):,:]
    return p_and_y[:,0:p_and_y.shape[1]//2], p_and_y[:,p_and_y.shape[1]//2:p_and_y.shape[1]]

def cov_shifter(p_, y_, shift_amount, covariates, big_classes, small_classes):
    p = p_
    y = y_
    for cl in big_classes:
        top_col = -1
        top_corr = 0
        for col in covariates:
            try:
                if abs(top_corr) < abs(np.corrcoef(covariates[col],y[:,cl])[0,1]):
                    top_col = col
                    top_corr = np.corrcoef(covariates[col],y[:,cl])[0,1]
            except:
                continue

        p_and_y = np.concatenate((p, y), axis = 1)
        number_of_majority_class = get_number_of_class(p_and_y, cl)
        f_p_and_y = np.concatenate((covariates[[top_col]], p_and_y), axis = 1)
        np.random.shuffle(f_p_and_y)
        f_p_and_y = f_p_and_y[f_p_and_y[:,1+(f_p_and_y.shape[1]//2)+cl].argsort()]
        if top_corr > 0:
            f_p_and_y = np.flipud(f_p_and_y)
        f_p_and_y = f_p_and_y[math.floor(number_of_majority_class*shift_amount):,:]
    return f_p_and_y[:,1:1+f_p_and_y.shape[1]//2], f_p_and_y[:,1+f_p_and_y.shape[1]//2:f_p_and_y.shape[1]]


def flip_prior_shifter(p_, y_, shift_amount, big_classes, small_classes):
    p = p_
    y = y_
    p_and_y = np.concatenate((p, y), axis = 1)
    np.random.shuffle(p_and_y)

    for cl in big_classes:
        p_and_y = p_and_y[p_and_y[:,(p_and_y.shape[1]//2)+cl].argsort()]
        number_of_majority_class = get_number_of_class(p_and_y, cl)

        for i in range(math.floor(number_of_majority_class*shift_amount)):

            p_and_y[i,(p_and_y.shape[1]//2)+cl] = 0.0
            p_and_y[i,p_and_y.shape[1]//2+random.choice(small_classes)] = 1.0

    return p_and_y[:,0:p_and_y.shape[1]//2], p_and_y[:,p_and_y.shape[1]//2:p_and_y.shape[1]]
