import numpy as np
import cvxpy as cvx

def get_pi(p):
    pi = np.sum(p, axis=0) / p.shape[0]
    return pi / sum(pi)

def PPS_adjuster(p, new_pi, error, big_classes, small_classes):
    a = p
    old_pi = get_pi(a)
    ratio = new_pi/old_pi
    a = a * ratio
    rows_sums = np.sum(a, axis=1)
    a = (a.T / rows_sums).T

    return a


def BS_general_adjuster(p_, new_pi, error, big_classes, small_classes):
    p = p_
    old_pi = get_pi(p)
    s_min = 0
    s_max = 1
    number_of_rows = p.shape[0]
    number_of_cols = p.shape[1]
    rower = np.ones(number_of_cols)
    coler = np.ones(number_of_rows)
    A = cvx.Variable((number_of_rows,number_of_cols))
    constraints = [s_min <= A,
                    A <= s_max,
                    A*rower == coler,
                    A.T*coler == number_of_rows*new_pi]
    objective = cvx.Minimize(cvx.sum_squares(p_ - A))
    optimizer_name = "error"
    try:
        problem = cvx.Problem(objective, constraints)
        problem.solve(solver=cvx.OSQP, verbose=True)
        p = A.value
        optimizer_name = "OSQP"
    except:
        problem = cvx.Problem(objective, constraints)
        problem.solve(solver=cvx.ECOS, verbose=True)
        p = A.value
        optimizer_name = "ECOS"
    return p, optimizer_name


def LL_general_adjuster(p_, new_pi, error, big_classes, small_classes):
    p = p_
    old_pi = get_pi(p)
    s_min = 0
    s_max = 1
    number_of_rows = p.shape[0]
    number_of_cols = p.shape[1]
    rower = np.ones(number_of_cols)
    coler = np.ones(number_of_rows)
    A = cvx.Variable((number_of_rows,number_of_cols))
    constraints = [s_min <= A,
                    A <= s_max,
                    A*rower == coler,
                    A.T*coler == number_of_rows*new_pi]
    objective = cvx.Minimize(cvx.sum(cvx.kl_div(A, p)))
    optimizer_name = "error"
    try:
        problem = cvx.Problem(objective, constraints)
        problem.solve(solver=cvx.ECOS, verbose=True)
        p = A.value
        optimizer_name = "ECOS"
    except:
        problem = cvx.Problem(objective, constraints)
        problem.solve(solver=cvx.SCS, verbose=True)
        p = A.value
        optimizer_name = "SCS"
    return p, optimizer_name
