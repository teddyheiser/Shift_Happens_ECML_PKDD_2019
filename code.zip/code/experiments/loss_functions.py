import numpy as np
import math

def average_loss(func, p, y):
    total_loss = 0.0
    #print(p)
    #print(p[0,:])
    p = np.asmatrix(p)
    y = np.asmatrix(y)
    for i in range(p.shape[0]):
        #print(i)
        total_loss += func(p[i,:], y[i,:])
    return total_loss / p.shape[0]

def brier_scorer(p_i, y_i):
    bs = 0.0
    #print(p_i)
    #print(y_i)
    for j in range(p_i.shape[1]):
        bs += (y_i[0,j] - p_i[0,j])**2
    return bs

def log_losser(p_i, y_i):
    ll = 0.0
    ##############################################
    for j in range(p_i.shape[1]):
        if p_i[0,j] <= 0.0:
            p_i[0,j] = 0.0000001
        elif p_i[0,j] >= 1.0:
            p_i[0,j] = 0.9999999
    ##############################################
    for j in range(p_i.shape[1]):
        ll += -1 * (y_i[0,j]*math.log(p_i[0,j]))
    return ll
