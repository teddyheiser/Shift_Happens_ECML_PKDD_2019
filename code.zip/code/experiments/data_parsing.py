import re
import pandas as pd
import numpy as np
from adjusters import *

def get_class_names(data):
    header = data.columns.values.tolist()[1][0:3]
    class_names = [str(x) for x in data[header + "correct"].unique()]
    return class_names

def get_confidences(data, class_names, num_classes):
    header = data.columns.values.tolist()[1][0:3]
    confidence_names = [header + "confidence." + x for x in class_names]
    confidence_names = [re.sub('[^0-9a-zA-Z]', '.', w) for w in confidence_names]
    confidence_names = data.columns.values.tolist()[(-2-num_classes):-2]
    return data[confidence_names].values

def get_labels(data, class_names):
    number_of_rows = data.values.shape[0]
    y = np.zeros([number_of_rows, len(class_names)])
    header = data.columns.values.tolist()[1][0:3]
    corrects = [str(x) for x in data[header + "correct"].values]
    for i in range(number_of_rows):
        for j in range(len(class_names)):
            if corrects[i] == class_names[j]:
                y[i,j] = 1
    return y

def get_covariates(data, class_names):
    return data.iloc[:,1:-(5 + len(class_names))]


def get_big_classes(labels):
    big_classes = []
    pi = get_pi(labels)
    pi = pi.tolist()
    while sum(pi) > 0.5:
        max_size = max(pi)
        max_index = pi.index(max_size)
        big_classes.append(max_index)
        pi[max_index] = 0.0
    return big_classes



def get_small_classes(num_labels, big_classes):
    small_classes = [x for x in range(num_labels)]
    for cl in big_classes:
        small_classes.remove(cl)
    return small_classes
